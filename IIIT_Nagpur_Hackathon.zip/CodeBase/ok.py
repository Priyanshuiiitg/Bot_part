import google.generativeai as palm
palm.configure(api_key="AIzaSyCEq6utrfmctmtT9JLTtuzFZUPBUzsf9lw")
reply = palm.chat(context="Be an Educational Chatbot for Juniors: Empowering Students to Navigate Academic and Non-Academic Challenges", messages="give me an paragraph on cow")
print(reply.last)